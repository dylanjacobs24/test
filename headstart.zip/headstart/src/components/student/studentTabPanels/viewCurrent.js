import React from "react";

function ViewCurrent() {
  

  return (
    <div>
      <h1>Student View Current Component</h1>
    </div>
  );
}

export { ViewCurrent };
