import React from "react";

function ViewRejected() {
  return (
    <div>
      <h1>Student View Recjected Component</h1>
    </div>
  );
}

export { ViewRejected };
