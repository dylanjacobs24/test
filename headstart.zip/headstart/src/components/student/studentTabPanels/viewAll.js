import React from "react";

function ViewAll() {
  return <div><h1>Student View All Time Sheets Component</h1></div>;
}

export { ViewAll };
