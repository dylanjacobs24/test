import React from "react";

function StudentProfile() {
  return (
    <div>
      <h1>StudentProfile</h1>
    </div>
  );
}

export { StudentProfile };
