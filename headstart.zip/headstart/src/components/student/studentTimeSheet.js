import React from 'react'
import {StudentTabs} from "../tabs/"

function StudentTimeSheet() {
    return (
        <div>
            <StudentTabs/>
        </div>
    )
}

export  {StudentTimeSheet}
