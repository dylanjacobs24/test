import React from 'react'

function StudentSettings() {
    return (
        <div>
            <h1>Student Settings</h1>
        </div>
    )
}

export  {StudentSettings}
