import React from "react";

function AdminTimeSheet() {
  return (
    <div>
      <h1>Admin Time Sheet</h1>
    </div>
  );
}

export { AdminTimeSheet };
