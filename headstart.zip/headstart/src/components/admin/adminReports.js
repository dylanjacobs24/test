import React from "react";

function AdminReports() {
  return (
    <div>
      <h1>Admin Reports</h1>
    </div>
  );
}

export { AdminReports };
