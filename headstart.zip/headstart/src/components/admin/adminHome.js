import React from "react";
import {DataTable} from "../DataTable"
import {} from "../Grid"


function AdminHome() {
  return (
    <div>
      <h1>Admin Home components</h1>
    </div>
  );
}

export { AdminHome };
