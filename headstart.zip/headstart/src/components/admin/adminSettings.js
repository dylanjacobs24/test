import React from "react";

function AdminSettings() {
  return (
    <div>
      <h1> admin settings</h1>
    </div>
  );
}

export { AdminSettings };
