import { makeStyles } from "@material-ui/core";

export const useRadioGroupStyles = makeStyles(() => ({
  radioForm: {
    margin: "10px 0px",
  },
}));
