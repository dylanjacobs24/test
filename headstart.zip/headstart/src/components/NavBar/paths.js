export const studentPath = [
  { pathName: "Home", path: "/home" },
  { pathName: "TimeSheet", path: "/time-sheet" },
  { pathName: "Settings", path: "/settings" },
];

export const adminPath = [
  { pathName: "Home", path: "/home" },
  { pathName: "TimeSheet", path: "/time-sheet" },
  { pathName: "Reports", path: "/reports" },
  { pathName: "Settings", path: "/settings" },
];
