import React from "react";

function Page404() {
  return (
    <div className="main-container">
      <h1>404 ERROR PAGE NOT FOUND</h1>
    </div>
  );
}

export { Page404 };
