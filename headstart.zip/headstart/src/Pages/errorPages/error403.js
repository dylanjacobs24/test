import React from "react";

function Page403() {
  return (
    <div>
      <h1>STATUS CODE: 403</h1>
      <h1>You don't have permission to access this page</h1>
    </div>
  );
}

export { Page403 };
