export const alertType = {
    SUCCESS: 'ALERT_SUCCESS',
    ERROR: 'ALERT_ERROR',
    MESSAGE: "ALERT_MESSAGE"
}