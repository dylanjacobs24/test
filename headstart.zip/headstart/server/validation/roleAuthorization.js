const ROLE = {
  ADMIN: "admin",
  STUDENT: "student",
};

const admin = { id: 1, role: ROLE.ADMIN };

const student = { id: 2, role: ROLE.STUDENT };

module.exports = {admin, student};
